<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Cargar las dependencias de PHPMailer
require './PHPMailer-master/src/Exception.php';
require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';

// Configuración de la base de datos
$server = "localhost";
$username = "reserva_user"; 
$password = "securepassword123";
$database = "ReservaProyectores";

// Conectar a la base de datos
$connection = mysqli_connect($server, $username, $password, $database);

// Verificar la conexión
if (!$connection) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Verificar si los datos del formulario fueron enviados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar y limpiar datos del formulario
    $proyector = $_POST['proyector'];
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $nombre = mysqli_real_escape_string($connection, $_POST['nombre']);
    $apellido = mysqli_real_escape_string($connection, $_POST['apellido']);
    $matricula = mysqli_real_escape_string($connection, $_POST['matricula']);
    $fecha = mysqli_real_escape_string($connection, $_POST['fecha']);
    $hora_inicio = mysqli_real_escape_string($connection, $_POST['hora_inicio']);
    $hora_fin = mysqli_real_escape_string($connection, $_POST['hora_fin']);
    $comentarios = mysqli_real_escape_string($connection, $_POST['comentarios']);

    // Insertar datos en la tabla
    $query = "INSERT INTO reservas (email, nombres, apellidos, matricula, fecha, hora_inicio, hora_fin, comentario)
              VALUES ('$email', '$nombre', '$apellido', '$matricula', '$fecha', '$hora_inicio', '$hora_fin', '$comentarios')";

    if (mysqli_query($connection, $query)) {
        // Si la reserva se realiza correctamente, enviar un correo al administrador
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'taisurvey.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'joshua@taisurvey.com';
        $mail->Password = 'joshua_123#$';
        $mail->Port = 587;

        // Configuración del correo
        $mail->setFrom('joshua@taisurvey.com', 'Sistema de Reservas');
        $mail->addAddress('jesurum18@gmail.com', 'Administrador');
        $mail->Subject = 'Nueva Reserva de Proyector';

        // Cuerpo del correo
        $mail->isHTML(true);
        $mail->Body = "
            <html>
            <head><title>Nueva Reserva</title></head>
            <body>
                <p><strong>Se ha registrado una nueva reserva de proyector:</strong></p>
                <ul>
                    <li><strong>Proyector:</strong> $proyector</li>
                    <li><strong>Nombre:</strong> $nombre $apellido</li>
                    <li><strong>Matrícula:</strong> $matricula</li>
                    <li><strong>Correo:</strong> $email</li>
                    <li><strong>Fecha:</strong> $fecha</li>
                    <li><strong>Hora de Inicio:</strong> $hora_inicio</li>
                    <li><strong>Hora de Fin:</strong> $hora_fin</li>
                    <li><strong>Comentarios:</strong> $comentarios</li>
                </ul>
                <p>Por favor, revisa el sistema para más detalles.</p>
            </body>
            </html>";

        $mail->AltBody = "Se ha registrado una nueva reserva de proyector. 
                          Proyector: $proyector, Nombre: $nombre $apellido, Matrícula: $matricula, 
                          Correo: $email, Fecha: $fecha, Hora de Inicio: $hora_inicio, Hora de Fin: $hora_fin, Comentarios: $comentarios.";

        // Enviar el correo
        if ($mail->send()) {
            echo "<h3>Reserva realizada correctamente y notificación enviada al administrador.</h3>";
        } else {
            echo "<h3>Reserva realizada correctamente, pero no se pudo enviar el correo al administrador.</h3>";
            echo "<p>Error del correo: " . $mail->ErrorInfo . "</p>";
        }
    } else {
        echo "<p>Error al realizar la reserva: " . mysqli_error($connection) . "</p>";
    }

    // Agregar el botón de regresar
    echo '<button onclick="window.location.href=\'ReservaProyector.html\'">Regresar</button>';
}

// Cerrar conexión
mysqli_close($connection);
?>
