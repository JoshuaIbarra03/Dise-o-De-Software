<?php
// Conexión a la base de datos
$server = "localhost";
$username = "reserva_user";
$password = "securepassword123";
$database = "ReservaProyectores";

$connection = mysqli_connect($server, $username, $password, $database);

if (!$connection) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Mostrar mensaje si se pasa en la URL
$mensaje = "";
if (isset($_GET['mensaje'])) {
    $mensaje = $_GET['mensaje'];
}

// Si el formulario fue enviado para actualizar el estado de una reserva
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $action = $_POST['action'];
    
    if ($action == 'confirmar') {
        // Actualizar estado a "confirmado"
        $query = "UPDATE reservas SET estado = 'confirmado' WHERE id = ?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        
        // Redirigir con mensaje de éxito
        header("Location: ConsultarReservas.php?mensaje=Reserva confirmada");
        exit();
    } elseif ($action == 'cancelar') {
        // Actualizar estado a "cancelado"
        $query = "UPDATE reservas SET estado = 'cancelado' WHERE id = ?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        
        // Redirigir con mensaje de cancelación
        header("Location: ConsultarReservas.php?mensaje=Reserva cancelada");
        exit();
    }
}

// Consulta para obtener todas las reservas
$query = "SELECT * FROM reservas";
$result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Reservas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #007BFF;
            color: white;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            padding: 8px 12px;
            border: none;
            color: white;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-confirm {
            background-color: #28a745;
        }

        .btn-confirm:hover {
            background-color: #218838;
        }

        .btn-cancel {
            background-color: #dc3545;
        }

        .btn-cancel:hover {
            background-color: #c82333;
        }

        .btn-action {
            display: inline-block;
            margin: 2px;
        }

        .no-data {
            text-align: center;
            color: #666;
            font-size: 18px;
            padding: 20px;
        }

        /* Estilos para el cuadro de mensaje */
        .mensaje {
            background-color: #fff;
            color: #333;
            padding: 15px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
            font-size: 18px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <h1>Consultar Reservas</h1>

    <?php if ($mensaje): ?>
        <div class="mensaje"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Correo</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Matrícula</th>
                <th>Fecha</th>
                <th>Hora Inicio</th>
                <th>Hora Fin</th>
                <th>Estado</th>
                <th>Comentario</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['nombres']}</td>
                        <td>{$row['apellidos']}</td>
                        <td>{$row['matricula']}</td>
                        <td>{$row['fecha']}</td>
                        <td>{$row['hora_inicio']}</td>
                        <td>{$row['hora_fin']}</td>
                        <td>{$row['estado']}</td>
                        <td>{$row['comentario']}</td>
                        <td>
                            <form action='ConsultarReservas.php' method='POST' class='btn-action'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <input type='hidden' name='action' value='confirmar'>
                                <button type='submit' class='btn btn-confirm'>Confirmar</button>
                            </form>
                            <form action='ConsultarReservas.php' method='POST' class='btn-action'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <input type='hidden' name='action' value='cancelar'>
                                <button type='submit' class='btn btn-cancel'>Cancelar</button>
                            </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='11' class='no-data'>No hay reservas registradas.</td></tr>";
            }

            mysqli_close($connection);
            ?>
        </tbody>
    </table>
</body>
</html>
