<?php
// Configuración de conexión
$server = "localhost";
$user = "reserva_user";
$pwd = "securepassword123";
$database = "ReservaProyectores";

// Establecer conexión
$connection = mysqli_connect($server, $user, $pwd, $database);

// Verificar conexión
if (!$connection) {
    die("Error en la conexión: " . mysqli_connect_error());
} else {
    echo "Conexión exitosa a la base de datos ReservaProyectores.";
}
?>
