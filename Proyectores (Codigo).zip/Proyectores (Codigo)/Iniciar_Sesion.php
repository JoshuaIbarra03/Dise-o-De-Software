<?php
// Configuración de conexión
$server = "localhost";
$user = "reserva_user";
$pwd = "securepassword123";
$database = "ReservaProyectores";

// Establecer conexión
$connection = mysqli_connect($server, $user, $pwd, $database);

// Verificar conexión
if (!$connection) {
    die("Error en la conexión: " . mysqli_connect_error());
}

// Obtener datos del formulario
$email = $_POST['email'];
$password = $_POST['password'];

// Validar campos no vacíos
if (empty($email) || empty($password)) {
    die("Por favor, completa todos los campos.");
}

// Consulta para verificar si el usuario existe
$query = "SELECT contrasena FROM usuarios WHERE correo = ?";
$stmt = mysqli_prepare($connection, $query);

// Usar consultas preparadas para prevenir inyecciones SQL
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $hashed_password);
mysqli_stmt_fetch($stmt);

if ($hashed_password) {
    // Verificar contraseña
    if (password_verify($password, $hashed_password)) {
        // Redirigir a la página principal después de un inicio de sesión exitoso
        header("Location: ReservaProyector.html");
        exit();
    } else {
        echo "Contraseña incorrecta.";
    }
} else {
    echo "El correo ingresado no está registrado.";
}

// Cerrar conexión
mysqli_stmt_close($stmt);
mysqli_close($connection);
?>
