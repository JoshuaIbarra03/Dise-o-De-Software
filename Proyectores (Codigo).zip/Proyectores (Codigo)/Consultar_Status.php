<?php
// Conexión a la base de datos
$server = "localhost";
$username = "reserva_user";
$password = "securepassword123";
$database = "ReservaProyectores";

$connection = mysqli_connect($server, $username, $password, $database);

if (!$connection) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Mostrar mensaje si se pasa en la URL
$mensaje = "";
if (isset($_GET['mensaje'])) {
    $mensaje = $_GET['mensaje'];
}

// Consulta para obtener todas las reservas
$query = "SELECT * FROM reservas";
$result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Reservas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }

        .btn-regresar {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .btn-regresar:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #007BFF;
            color: white;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        .no-data {
            text-align: center;
            color: #666;
            font-size: 18px;
            padding: 20px;
        }

        .mensaje {
            background-color: #fff;
            color: #333;
            padding: 15px;
            margin: 10px auto;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
            font-size: 18px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
        }
    </style>
</head>
<body>
    <!-- Botón "Regresar" -->
    <a href="ReservaProyector.html" class="btn-regresar">Regresar</a>

    <h1>Consultar Reservas</h1>

    <?php if ($mensaje): ?>
        <div class="mensaje"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Correo</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Matrícula</th>
                <th>Fecha</th>
                <th>Hora Inicio</th>
                <th>Hora Fin</th>
                <th>Estado</th>
                <th>Comentario</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['nombres']}</td>
                        <td>{$row['apellidos']}</td>
                        <td>{$row['matricula']}</td>
                        <td>{$row['fecha']}</td>
                        <td>{$row['hora_inicio']}</td>
                        <td>{$row['hora_fin']}</td>
                        <td>{$row['estado']}</td>
                        <td>{$row['comentario']}</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='10' class='no-data'>No hay reservas registradas.</td></tr>";
            }

            mysqli_close($connection);
            ?>
        </tbody>
    </table>
</body>
</html>
