<?php
// Conexión a la base de datos
$server = "localhost";
$username = "reserva_user";
$password = "securepassword123";
$database = "ReservaProyectores";

$connection = mysqli_connect($server, $username, $password, $database);

if (!$connection) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Mostrar mensaje si se pasa en la URL
if (isset($_GET['mensaje'])) {
    echo "<p style='color: green; text-align: center; font-size: 18px;'>" . $_GET['mensaje'] . "</p>";
}

// Consulta para obtener todas las reservas
$query = "SELECT * FROM reservas";
$result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Reservas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #007BFF;
            color: white;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            padding: 8px 12px;
            border: none;
            color: white;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-confirm {
            background-color: #28a745;
        }

        .btn-confirm:hover {
            background-color: #218838;
        }

        .btn-cancel {
            background-color: #dc3545;
        }

        .btn-cancel:hover {
            background-color: #c82333;
        }

        .btn-action {
            display: inline-block;
            margin: 2px;
        }

        .no-data {
            text-align: center;
            color: #666;
            font-size: 18px;
            padding: 20px;
        }

        /* Estilo para el botón de cerrar sesión */
        .logout-button {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: #f1f1f1;
            color: #333;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .logout-button:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>

<a href="RegistrarUsuario.html" class="logout-button">Cerrar Sesión</a>

<h1>Consultar Reservas</h1>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Correo</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Matrícula</th>
            <th>Fecha</th>
            <th>Hora Inicio</th>
            <th>Hora Fin</th>
            <th>Estado</th>
            <th>Comentario</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['nombres']}</td>
                    <td>{$row['apellidos']}</td>
                    <td>{$row['matricula']}</td>
                    <td>{$row['fecha']}</td>
                    <td>{$row['hora_inicio']}</td>
                    <td>{$row['hora_fin']}</td>
                    <td>{$row['estado']}</td>
                    <td>{$row['comentario']}</td>
                    <td>
                        <form action='Consultar_Reservas.php' method='POST' class='btn-action'>
                            <input type='hidden' name='id' value='{$row['id']}'>
                            <input type='hidden' name='action' value='confirmar'>
                            <button type='submit' class='btn btn-confirm'>Confirmar</button>
                        </form>
                        <form action='Consultar_Reservas.php' method='POST' class='btn-action'>
                            <input type='hidden' name='id' value='{$row['id']}'>
                            <input type='hidden' name='action' value='cancelar'>
                            <button type='submit' class='btn btn-cancel'>Cancelar</button>
                        </form>
                    </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='11' class='no-data'>No hay reservas registradas.</td></tr>";
        }

        mysqli_close($connection);
        ?>
    </tbody>
</table>
</body>
</html>

