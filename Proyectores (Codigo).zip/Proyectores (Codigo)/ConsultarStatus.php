<?php
// Conexión a la base de datos
$server = "localhost";
$username = "reserva_user";
$password = "securepassword123";
$database = "ReservaProyectores";

$connection = mysqli_connect($server, $username, $password, $database);

if (!$connection) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Verificar si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];  // La contraseña proporcionada por el usuario

    // Consulta para verificar si el correo y la contraseña coinciden
    $query = "SELECT id, estado FROM reservas WHERE email = ? AND password = ?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, 'ss', $email, $password); // 's' para string
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $id_reserva, $estado);
    mysqli_stmt_fetch($stmt);

    // Verificar si se encontró la reserva con las credenciales
    if ($id_reserva) {
        $mensaje = "El estado de tu reserva con ID {$id_reserva} es: " . $estado;
    } else {
        $mensaje = "Correo electrónico o contraseña incorrectos.";
    }
    mysqli_stmt_close($stmt);
} else {
    $mensaje = '';
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Estado de Reserva</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .form-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
            color: #333;
        }
    </style>
</head>
<body>

    <h1>Verificar Estado de tu Reserva</h1>

    <div class="form-container">
        <form action="Consultar_Status.php" method="POST">
            <label for="email">Correo Electrónico:</label>
            <input type="email" name="email" id="email" required>

            <label for="password">Contraseña:</label>
            <input type="password" name="password" id="password" required>

            <button type="submit">Verificar Estado</button>
        </form>
    </div>

    <?php if ($mensaje): ?>
        <div class="message">
            <p><?php echo $mensaje; ?></p>
        </div>
    <?php endif; ?>

</body>
</html>

