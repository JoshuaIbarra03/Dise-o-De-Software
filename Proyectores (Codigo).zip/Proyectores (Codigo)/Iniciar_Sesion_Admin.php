<?php
// Configuración de la base de datos
$server = "localhost";
$username = "reserva_user"; 
$password = "securepassword123";
$database = "ReservaProyectores";

// Conexión a la base de datos
$connection = mysqli_connect($server, $username, $password, $database);

// Verificar conexión
if (!$connection) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Verificar si se enviaron los datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar y limpiar los datos del formulario
    $admin_email = mysqli_real_escape_string($connection, $_POST['admin_email']);
    $admin_password = mysqli_real_escape_string($connection, $_POST['admin_password']);

    // Consultar la base de datos para verificar las credenciales
    $query = "SELECT * FROM Administrador WHERE correo = '$admin_email'";
    $result = mysqli_query($connection, $query);

    if (mysqli_num_rows($result) == 1) {
        $admin_data = mysqli_fetch_assoc($result);

        // Verificar la contraseña
        if ($admin_password === $admin_data['contrasena']) {
            // Iniciar sesión y redirigir
            session_start();
            $_SESSION['adminID'] = $admin_data['adminID'];
            $_SESSION['adminCorreo'] = $admin_data['correo'];
            echo "<h3>Inicio de sesión exitoso. Redirigiendo...</h3>";
            header("Refresh: 2; url=ConsultarReservas.php"); // Cambiar por la URL del panel de administrador
            exit;
        } else {
            echo "<h3>Contraseña incorrecta. Por favor, inténtelo nuevamente.</h3>";
        }
    } else {
        echo "<h3>Correo no encontrado. Por favor, verifique los datos ingresados.</h3>";
    }
}

// Cerrar conexión
mysqli_close($connection);
?>
