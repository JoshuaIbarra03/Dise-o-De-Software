<?php
// Configuración de conexión
$server = "localhost";
$user = "reserva_user";
$pwd = "securepassword123";
$database = "ReservaProyectores";

// Establecer conexión
$connection = mysqli_connect($server, $user, $pwd, $database);

// Verificar conexión
if (!$connection) {
    die("Error en la conexión: " . mysqli_connect_error());
}

// Obtener datos del formulario
$email = $_POST['email'];
$password = $_POST['password'];

// Validar campos no vacíos
if (empty($email) || empty($password)) {
    die("<p>Por favor, completa todos los campos.</p><button onclick=\"window.location.href='RegistrarUsuario.html'\">Regresar</button>");
}

// Encriptar contraseña (buena práctica)
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insertar datos en la tabla usuarios
$query = "INSERT INTO usuarios (correo, contrasena) VALUES ('$email', '$hashed_password')";

if (mysqli_query($connection, $query)) {
    echo "<p>Usuario registrado exitosamente.</p>";
    echo "<button onclick=\"window.location.href='RegistrarUsuario.html'\">Regresar</button>";
} else {
    echo "<p>Error al registrar usuario: " . mysqli_error($connection) . "</p>";
    echo "<button onclick=\"window.location.href='RegistrarUsuario.html'\">Regresar</button>";
}

// Cerrar conexión
mysqli_close($connection);
?>
